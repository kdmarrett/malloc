// Karl Marrett
// Nan Jiang
// CSE 374 HW6
// Feb 20th
// print_heap.c that prints free list in given format for dist program

#include "mem_impl.h"
#include "mem.h"

void print_heap(FILE * f) {
}
